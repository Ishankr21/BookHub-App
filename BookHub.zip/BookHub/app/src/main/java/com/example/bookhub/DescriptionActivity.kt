package com.example.bookhub

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.bookhub.database.BookDatabase
import com.example.bookhub.database.BookEntity
import com.example.bookhub.model.Book
import com.example.bookhub.util.ConnectivityManager
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.recycler_dashboard_single_row.*
import org.json.JSONException
import org.json.JSONObject

class DescriptionActivity : AppCompatActivity() {
    lateinit var imgBookImg:ImageView
    lateinit var txtBkName:TextView
    lateinit var txtBkRating:TextView
    lateinit var txtBkPrice:TextView
    lateinit var txtBkAuthor:TextView
    lateinit var desc:TextView
    lateinit var Favbtn:Button

    var bookId:String?="100"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_description)
        imgBookImg = findViewById(R.id.imgBookImg)
        txtBkName = findViewById(R.id.txtBkName)
        txtBkAuthor = findViewById(R.id.txtBkAuthor)
        Favbtn=findViewById(R.id.Favbtn)
        txtBkPrice = findViewById(R.id.txtBkPrice)
        txtBkRating = findViewById(R.id.txtBkRating)
        desc = findViewById(R.id.desc)
        if (intent != null) {
            bookId = intent.getStringExtra("book_id")

        } else {
            finish()
            Toast.makeText(this@DescriptionActivity, "Some Error Occured!!", Toast.LENGTH_LONG)
                .show()
        }
        if (bookId == "100") {
            finish()
            Toast.makeText(this@DescriptionActivity, "Some Error Occured!!", Toast.LENGTH_LONG)
                .show()

        }
        val queue = Volley.newRequestQueue(this@DescriptionActivity)
        val url = "http://13.235.250.119/v1/book/get_book/"
        val jsonParams = JSONObject()
        jsonParams.put("book_id", bookId)


        if((ConnectivityManager().checkConnectivity(this@DescriptionActivity))==true)
        {
            val jsonRequest =
                object : JsonObjectRequest(Request.Method.POST, url, jsonParams, Response.Listener {
                    try{

                        val success=it.getBoolean("success")
                        if(success)
                        {
                            val bookJSONObject=it.getJSONObject("book_data")
                            val bookImageUrl=bookJSONObject.getString("image")
                            Picasso.get().load(bookJSONObject.getString("image")).error(R.drawable.default_book_cover).into(imgBookImg)

                            txtBkName.text= bookJSONObject.getString("name")
                            txtBkAuthor.text=bookJSONObject.getString("author")
                            txtBkPrice.text=bookJSONObject.getString("price")

                            txtBkRating.text=bookJSONObject.getString("rating")
                            desc.text=bookJSONObject.getString("description")
                            val bookEntity=BookEntity(
                                bookId?.toInt() as Int,
                                txtBkName.text.toString(),
                                txtBkAuthor.text.toString(),
                                txtBkPrice.text.toString(),
                                txtBkRating.text.toString(),
                                desc.text.toString(),
                                bookImageUrl

                            )
                            val checkFav=DBAsyncTask(applicationContext,bookEntity,1).execute()
                            val isFav=checkFav.get()
                            if(isFav){
                                  Favbtn.text="Remove From Favourites"
                                  val favColor=ContextCompat.getColor(applicationContext,R.color.colorFavourite)
                                    Favbtn.setBackgroundColor(favColor)
                            }
                            else{
                                Favbtn.text="Add to Favourites"
                                val noFavColor=ContextCompat.getColor(applicationContext,R.color.colorPrimary)
                                Favbtn.setBackgroundColor(noFavColor)
                            }
                            Favbtn.setOnClickListener{
                                if(!DBAsyncTask(applicationContext,bookEntity,1).execute().get()) {
                                    val async =
                                        DBAsyncTask(applicationContext, bookEntity, 2).execute()
                                    val result = async.get()
                                    if (result)
                                    {
                                        Toast.makeText(this@DescriptionActivity,"Book Added To Favourites",Toast.LENGTH_LONG).show()
                                        Favbtn.text="Remove From Favourite"
                                        val favColor=ContextCompat.getColor(applicationContext,R.color.colorFavourite)
                                        Favbtn.setBackgroundColor(favColor)
                                    }
                                    else{
                                        Toast.makeText(this@DescriptionActivity,"Some Error Occured",Toast.LENGTH_LONG).show()

                                    }
                                }
                                else{
                                    val async =
                                        DBAsyncTask(applicationContext, bookEntity, 3).execute()
                                    val result = async.get()
                                    if (result)
                                    {
                                        Toast.makeText(this@DescriptionActivity,"Book Removed From Favourites",Toast.LENGTH_LONG).show()
                                        Favbtn.text="Add to Favourites"
                                        val noFavColor=ContextCompat.getColor(applicationContext,R.color.colorPrimary)
                                        Favbtn.setBackgroundColor(noFavColor)
                                    }
                                    else{
                                        Toast.makeText(this@DescriptionActivity,"Some Error Occured",Toast.LENGTH_LONG).show()

                                    }

                                }

                            }



                        }


                        else{
                            Toast.makeText(this@DescriptionActivity,"Some Error Occured!!!",Toast.LENGTH_LONG).show()


                        }

                    }
                    catch (e: Exception){
                        Toast.makeText(this@DescriptionActivity,"Some Unexpected Error Occured!!!",Toast.LENGTH_LONG).show()
                    }

                }, Response.ErrorListener {
                    Toast.makeText(this@DescriptionActivity,"Volley Error Occured!!!",Toast.LENGTH_LONG).show()

                }) {
                    override fun getHeaders(): MutableMap<String, String> {
                        val headers = HashMap<String, String>()
                        headers["Content-type"] = "application/json"
                        headers["token"] = "b0c526f96da201"
                        return headers
                    }
                }

            queue.add(jsonRequest)
        }else
        {
            val dialog = AlertDialog.Builder(this@DescriptionActivity)
            dialog.setTitle("Failure")
            dialog.setMessage("Internet Connection not Found")
            dialog.setPositiveButton("OPEN SETTINGS") { text, listner ->
                val settingsIntent= Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(settingsIntent)
                finish()
            }
            dialog.setNegativeButton("Exit") { text, listner ->
                ActivityCompat.finishAffinity(this@DescriptionActivity)
            }
            dialog.create()
            dialog.show()
        }



        }

    class DBAsyncTask(val context: Context,val bookEntity: BookEntity,val mode:Int):AsyncTask<Void,Void,Boolean>()
    {
        val db= Room.databaseBuilder(context,BookDatabase::class.java,"books-db").build()
        override fun doInBackground(vararg params: Void?): Boolean {
            when(mode)
            {
                1-> {
                    val book:BookEntity?=db.bookDao().getBookById(bookEntity.book_id.toString())
                    db.close()
                    return book!=null
                }
                2-> {
                    db.bookDao().insertBook(bookEntity)
                    db.close()
                    return true
                }
                3->{
                        db.bookDao().deleteBook(bookEntity)
                    db.close()
                    return true
                }

            }
            return false
        }

    }

    }
